import IntakeForm from "@/components/IntakeForm";

export default function Intake() {
  return <IntakeForm />;
}
